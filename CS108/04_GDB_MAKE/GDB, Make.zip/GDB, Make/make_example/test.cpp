#include<iostream>
using namespace std;
int main()
{
    int arr[1];
    cerr<<"Hey";
    int* pointer = NULL;
    cout<<*pointer;
}