void print_message_1();
void print_message_2();
int main()
{
    print_message_1();
    print_message_2();
}