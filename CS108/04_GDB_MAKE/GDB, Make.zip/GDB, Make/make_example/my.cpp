#include<iostream>
int my_add(int a, int b);
int main()
{
    int a = 1, b = 2;
    std::cout<<"Sum of a = "<<a<<" and b = "<<b<<" is "<<my_add(a, b)<<std::endl;
    return 0;
}